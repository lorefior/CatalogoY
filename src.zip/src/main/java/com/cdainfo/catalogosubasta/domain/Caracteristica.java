package com.cdainfo.catalogosubasta.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A Caracteristica.
 */
@Entity
@Table(name = "caracteristica")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Caracteristica implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre")
    private String nombre;

    @OneToMany(mappedBy = "caracteristica")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Valor> valors = new HashSet<>();

    @ManyToOne
    @JsonIgnoreProperties("caracteristicas")
    private TipoDato dato;

    @ManyToOne
    @JsonIgnoreProperties("caracteristicas")
    private Subcategoria subcategoria;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public Caracteristica nombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Set<Valor> getValors() {
        return valors;
    }

    public Caracteristica valors(Set<Valor> valors) {
        this.valors = valors;
        return this;
    }

    public Caracteristica addValor(Valor valor) {
        this.valors.add(valor);
        valor.setCaracteristica(this);
        return this;
    }

    public Caracteristica removeValor(Valor valor) {
        this.valors.remove(valor);
        valor.setCaracteristica(null);
        return this;
    }

    public void setValors(Set<Valor> valors) {
        this.valors = valors;
    }

    public TipoDato getDato() {
        return dato;
    }

    public Caracteristica dato(TipoDato tipoDato) {
        this.dato = tipoDato;
        return this;
    }

    public void setDato(TipoDato tipoDato) {
        this.dato = tipoDato;
    }

    public Subcategoria getSubcategoria() {
        return subcategoria;
    }

    public Caracteristica subcategoria(Subcategoria subcategoria) {
        this.subcategoria = subcategoria;
        return this;
    }

    public void setSubcategoria(Subcategoria subcategoria) {
        this.subcategoria = subcategoria;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Caracteristica)) {
            return false;
        }
        return id != null && id.equals(((Caracteristica) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Caracteristica{" +
            "id=" + getId() +
            ", nombre='" + getNombre() + "'" +
            "}";
    }
}
