package com.cdainfo.catalogosubasta.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A Producto.
 */
@Entity
@Table(name = "producto")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Producto implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "valor")
    private Double valor;

    @OneToMany(mappedBy = "producto")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Imagen> imagens = new HashSet<>();

    @OneToMany(mappedBy = "producto")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Valor> valors = new HashSet<>();

    @ManyToOne
    @JsonIgnoreProperties("productos")
    private TipoMoneda moneda;

    @ManyToOne
    @JsonIgnoreProperties("productos")
    private Subcategoria subcategoria;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public Producto titulo(String titulo) {
        this.titulo = titulo;
        return this;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Producto descripcion(String descripcion) {
        this.descripcion = descripcion;
        return this;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getValor() {
        return valor;
    }

    public Producto valor(Double valor) {
        this.valor = valor;
        return this;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Set<Imagen> getImagens() {
        return imagens;
    }

    public Producto imagens(Set<Imagen> imagens) {
        this.imagens = imagens;
        return this;
    }

    public Producto addImagen(Imagen imagen) {
        this.imagens.add(imagen);
        imagen.setProducto(this);
        return this;
    }

    public Producto removeImagen(Imagen imagen) {
        this.imagens.remove(imagen);
        imagen.setProducto(null);
        return this;
    }

    public void setImagens(Set<Imagen> imagens) {
        this.imagens = imagens;
    }

    public Set<Valor> getValors() {
        return valors;
    }

    public Producto valors(Set<Valor> valors) {
        this.valors = valors;
        return this;
    }

    public Producto addValor(Valor valor) {
        this.valors.add(valor);
        valor.setProducto(this);
        return this;
    }

    public Producto removeValor(Valor valor) {
        this.valors.remove(valor);
        valor.setProducto(null);
        return this;
    }

    public void setValors(Set<Valor> valors) {
        this.valors = valors;
    }

    public TipoMoneda getMoneda() {
        return moneda;
    }

    public Producto moneda(TipoMoneda tipoMoneda) {
        this.moneda = tipoMoneda;
        return this;
    }

    public void setMoneda(TipoMoneda tipoMoneda) {
        this.moneda = tipoMoneda;
    }

    public Subcategoria getSubcategoria() {
        return subcategoria;
    }

    public Producto subcategoria(Subcategoria subcategoria) {
        this.subcategoria = subcategoria;
        return this;
    }

    public void setSubcategoria(Subcategoria subcategoria) {
        this.subcategoria = subcategoria;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Producto)) {
            return false;
        }
        return id != null && id.equals(((Producto) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Producto{" +
            "id=" + getId() +
            ", titulo='" + getTitulo() + "'" +
            ", descripcion='" + getDescripcion() + "'" +
            ", valor=" + getValor() +
            "}";
    }
}
