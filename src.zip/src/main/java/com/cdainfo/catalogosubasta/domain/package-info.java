/**
 * JPA domain objects.
 */
package com.cdainfo.catalogosubasta.domain;
