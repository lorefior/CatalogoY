package com.cdainfo.catalogosubasta.repository;
import com.cdainfo.catalogosubasta.domain.TipoDato;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the TipoDato entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TipoDatoRepository extends JpaRepository<TipoDato, Long> {

}
