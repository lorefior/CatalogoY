/**
 * Spring Data JPA repositories.
 */
package com.cdainfo.catalogosubasta.repository;
