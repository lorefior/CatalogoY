/**
 * Spring Security configuration.
 */
package com.cdainfo.catalogosubasta.security;
