/**
 * Data Transfer Objects.
 */
package com.cdainfo.catalogosubasta.service.dto;
