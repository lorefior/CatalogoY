/**
 * Service layer beans.
 */
package com.cdainfo.catalogosubasta.service;
