package com.cdainfo.catalogosubasta.web.rest;

import com.cdainfo.catalogosubasta.domain.TipoDato;
import com.cdainfo.catalogosubasta.repository.TipoDatoRepository;
import com.cdainfo.catalogosubasta.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional; 
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.cdainfo.catalogosubasta.domain.TipoDato}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class TipoDatoResource {

    private final Logger log = LoggerFactory.getLogger(TipoDatoResource.class);

    private static final String ENTITY_NAME = "tipoDato";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TipoDatoRepository tipoDatoRepository;

    public TipoDatoResource(TipoDatoRepository tipoDatoRepository) {
        this.tipoDatoRepository = tipoDatoRepository;
    }

    /**
     * {@code POST  /tipo-datoes} : Create a new tipoDato.
     *
     * @param tipoDato the tipoDato to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new tipoDato, or with status {@code 400 (Bad Request)} if the tipoDato has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/tipo-datoes")
    public ResponseEntity<TipoDato> createTipoDato(@RequestBody TipoDato tipoDato) throws URISyntaxException {
        log.debug("REST request to save TipoDato : {}", tipoDato);
        if (tipoDato.getId() != null) {
            throw new BadRequestAlertException("A new tipoDato cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TipoDato result = tipoDatoRepository.save(tipoDato);
        return ResponseEntity.created(new URI("/api/tipo-datoes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /tipo-datoes} : Updates an existing tipoDato.
     *
     * @param tipoDato the tipoDato to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated tipoDato,
     * or with status {@code 400 (Bad Request)} if the tipoDato is not valid,
     * or with status {@code 500 (Internal Server Error)} if the tipoDato couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/tipo-datoes")
    public ResponseEntity<TipoDato> updateTipoDato(@RequestBody TipoDato tipoDato) throws URISyntaxException {
        log.debug("REST request to update TipoDato : {}", tipoDato);
        if (tipoDato.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        TipoDato result = tipoDatoRepository.save(tipoDato);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, tipoDato.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /tipo-datoes} : get all the tipoDatoes.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of tipoDatoes in body.
     */
    @GetMapping("/tipo-datoes")
    public List<TipoDato> getAllTipoDatoes() {
        log.debug("REST request to get all TipoDatoes");
        return tipoDatoRepository.findAll();
    }

    /**
     * {@code GET  /tipo-datoes/:id} : get the "id" tipoDato.
     *
     * @param id the id of the tipoDato to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the tipoDato, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/tipo-datoes/{id}")
    public ResponseEntity<TipoDato> getTipoDato(@PathVariable Long id) {
        log.debug("REST request to get TipoDato : {}", id);
        Optional<TipoDato> tipoDato = tipoDatoRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(tipoDato);
    }

    /**
     * {@code DELETE  /tipo-datoes/:id} : delete the "id" tipoDato.
     *
     * @param id the id of the tipoDato to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/tipo-datoes/{id}")
    public ResponseEntity<Void> deleteTipoDato(@PathVariable Long id) {
        log.debug("REST request to delete TipoDato : {}", id);
        tipoDatoRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
