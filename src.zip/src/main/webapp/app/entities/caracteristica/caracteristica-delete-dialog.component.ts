import { Component } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ICaracteristica } from 'app/shared/model/caracteristica.model';
import { CaracteristicaService } from './caracteristica.service';

@Component({
  templateUrl: './caracteristica-delete-dialog.component.html'
})
export class CaracteristicaDeleteDialogComponent {
  caracteristica: ICaracteristica;

  constructor(
    protected caracteristicaService: CaracteristicaService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  clear() {
    this.activeModal.dismiss('cancel');
  }

  confirmDelete(id: number) {
    this.caracteristicaService.delete(id).subscribe(() => {
      this.eventManager.broadcast({
        name: 'caracteristicaListModification',
        content: 'Deleted an caracteristica'
      });
      this.activeModal.dismiss(true);
    });
  }
}
