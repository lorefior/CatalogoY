import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';
import { ICaracteristica, Caracteristica } from 'app/shared/model/caracteristica.model';
import { CaracteristicaService } from './caracteristica.service';
import { ITipoDato } from 'app/shared/model/tipo-dato.model';
import { TipoDatoService } from 'app/entities/tipo-dato/tipo-dato.service';
import { ISubcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from 'app/entities/subcategoria/subcategoria.service';

@Component({
  selector: 'jhi-caracteristica-update',
  templateUrl: './caracteristica-update.component.html'
})
export class CaracteristicaUpdateComponent implements OnInit {
  isSaving: boolean;

  tipodatoes: ITipoDato[];

  subcategorias: ISubcategoria[];

  editForm = this.fb.group({
    id: [],
    nombre: [],
    dato: [],
    subcategoria: []
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected caracteristicaService: CaracteristicaService,
    protected tipoDatoService: TipoDatoService,
    protected subcategoriaService: SubcategoriaService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ caracteristica }) => {
      this.updateForm(caracteristica);
    });
    this.tipoDatoService
      .query()
      .subscribe((res: HttpResponse<ITipoDato[]>) => (this.tipodatoes = res.body), (res: HttpErrorResponse) => this.onError(res.message));
    this.subcategoriaService
      .query()
      .subscribe(
        (res: HttpResponse<ISubcategoria[]>) => (this.subcategorias = res.body),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  updateForm(caracteristica: ICaracteristica) {
    this.editForm.patchValue({
      id: caracteristica.id,
      nombre: caracteristica.nombre,
      dato: caracteristica.dato,
      subcategoria: caracteristica.subcategoria
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const caracteristica = this.createFromForm();
    if (caracteristica.id !== undefined) {
      this.subscribeToSaveResponse(this.caracteristicaService.update(caracteristica));
    } else {
      this.subscribeToSaveResponse(this.caracteristicaService.create(caracteristica));
    }
  }

  private createFromForm(): ICaracteristica {
    return {
      ...new Caracteristica(),
      id: this.editForm.get(['id']).value,
      nombre: this.editForm.get(['nombre']).value,
      dato: this.editForm.get(['dato']).value,
      subcategoria: this.editForm.get(['subcategoria']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICaracteristica>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackTipoDatoById(index: number, item: ITipoDato) {
    return item.id;
  }

  trackSubcategoriaById(index: number, item: ISubcategoria) {
    return item.id;
  }
}
