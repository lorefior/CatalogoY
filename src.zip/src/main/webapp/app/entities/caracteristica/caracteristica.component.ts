import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICaracteristica } from 'app/shared/model/caracteristica.model';
import { CaracteristicaService } from './caracteristica.service';
import { CaracteristicaDeleteDialogComponent } from './caracteristica-delete-dialog.component';

@Component({
  selector: 'jhi-caracteristica',
  templateUrl: './caracteristica.component.html'
})
export class CaracteristicaComponent implements OnInit, OnDestroy {
  caracteristicas: ICaracteristica[];
  eventSubscriber: Subscription;

  constructor(
    protected caracteristicaService: CaracteristicaService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal
  ) {}

  loadAll() {
    this.caracteristicaService.query().subscribe((res: HttpResponse<ICaracteristica[]>) => {
      this.caracteristicas = res.body;
    });
  }

  ngOnInit() {
    this.loadAll();
    this.registerChangeInCaracteristicas();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ICaracteristica) {
    return item.id;
  }

  registerChangeInCaracteristicas() {
    this.eventSubscriber = this.eventManager.subscribe('caracteristicaListModification', () => this.loadAll());
  }

  delete(caracteristica: ICaracteristica) {
    const modalRef = this.modalService.open(CaracteristicaDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.caracteristica = caracteristica;
  }
}
