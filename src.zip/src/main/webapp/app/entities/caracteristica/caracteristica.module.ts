import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Catalog0SharedModule } from 'app/shared/shared.module';
import { CaracteristicaComponent } from './caracteristica.component';
import { CaracteristicaDetailComponent } from './caracteristica-detail.component';
import { CaracteristicaUpdateComponent } from './caracteristica-update.component';
import { CaracteristicaDeleteDialogComponent } from './caracteristica-delete-dialog.component';
import { caracteristicaRoute } from './caracteristica.route';

@NgModule({
  imports: [Catalog0SharedModule, RouterModule.forChild(caracteristicaRoute)],
  declarations: [
    CaracteristicaComponent,
    CaracteristicaDetailComponent,
    CaracteristicaUpdateComponent,
    CaracteristicaDeleteDialogComponent
  ],
  entryComponents: [CaracteristicaDeleteDialogComponent]
})
export class Catalog0CaracteristicaModule {}
