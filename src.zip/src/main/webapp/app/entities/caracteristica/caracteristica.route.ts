import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Caracteristica } from 'app/shared/model/caracteristica.model';
import { CaracteristicaService } from './caracteristica.service';
import { CaracteristicaComponent } from './caracteristica.component';
import { CaracteristicaDetailComponent } from './caracteristica-detail.component';
import { CaracteristicaUpdateComponent } from './caracteristica-update.component';
import { ICaracteristica } from 'app/shared/model/caracteristica.model';

@Injectable({ providedIn: 'root' })
export class CaracteristicaResolve implements Resolve<ICaracteristica> {
  constructor(private service: CaracteristicaService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICaracteristica> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(map((caracteristica: HttpResponse<Caracteristica>) => caracteristica.body));
    }
    return of(new Caracteristica());
  }
}

export const caracteristicaRoute: Routes = [
  {
    path: '',
    component: CaracteristicaComponent,
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.caracteristica.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: CaracteristicaDetailComponent,
    resolve: {
      caracteristica: CaracteristicaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.caracteristica.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: CaracteristicaUpdateComponent,
    resolve: {
      caracteristica: CaracteristicaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.caracteristica.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: CaracteristicaUpdateComponent,
    resolve: {
      caracteristica: CaracteristicaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.caracteristica.home.title'
    },
    canActivate: [UserRouteAccessService]
  }
];
