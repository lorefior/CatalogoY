import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'producto',
        loadChildren: () => import('./producto/producto.module').then(m => m.Catalog0ProductoModule)
      },
      {
        path: 'imagen',
        loadChildren: () => import('./imagen/imagen.module').then(m => m.Catalog0ImagenModule)
      },
      {
        path: 'categoria',
        loadChildren: () => import('./categoria/categoria.module').then(m => m.Catalog0CategoriaModule)
      },
      {
        path: 'subcategoria',
        loadChildren: () => import('./subcategoria/subcategoria.module').then(m => m.Catalog0SubcategoriaModule)
      },
      {
        path: 'caracteristica',
        loadChildren: () => import('./caracteristica/caracteristica.module').then(m => m.Catalog0CaracteristicaModule)
      },
      {
        path: 'tipo-moneda',
        loadChildren: () => import('./tipo-moneda/tipo-moneda.module').then(m => m.Catalog0TipoMonedaModule)
      },
      {
        path: 'tipo-dato',
        loadChildren: () => import('./tipo-dato/tipo-dato.module').then(m => m.Catalog0TipoDatoModule)
      },
      {
        path: 'valor',
        loadChildren: () => import('./valor/valor.module').then(m => m.Catalog0ValorModule)
      }
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ])
  ]
})
export class Catalog0EntityModule {}
