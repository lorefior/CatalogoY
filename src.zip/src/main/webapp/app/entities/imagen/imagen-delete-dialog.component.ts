import { Component } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IImagen } from 'app/shared/model/imagen.model';
import { ImagenService } from './imagen.service';

@Component({
  templateUrl: './imagen-delete-dialog.component.html'
})
export class ImagenDeleteDialogComponent {
  imagen: IImagen;

  constructor(protected imagenService: ImagenService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  clear() {
    this.activeModal.dismiss('cancel');
  }

  confirmDelete(id: number) {
    this.imagenService.delete(id).subscribe(() => {
      this.eventManager.broadcast({
        name: 'imagenListModification',
        content: 'Deleted an imagen'
      });
      this.activeModal.dismiss(true);
    });
  }
}
