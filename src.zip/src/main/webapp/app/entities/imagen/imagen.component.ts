import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager, JhiDataUtils } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { IImagen } from 'app/shared/model/imagen.model';
import { ImagenService } from './imagen.service';
import { ImagenDeleteDialogComponent } from './imagen-delete-dialog.component';

@Component({
  selector: 'jhi-imagen',
  templateUrl: './imagen.component.html'
})
export class ImagenComponent implements OnInit, OnDestroy {
  imagens: IImagen[];
  eventSubscriber: Subscription;

  constructor(
    protected imagenService: ImagenService,
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal
  ) {}

  loadAll() {
    this.imagenService.query().subscribe((res: HttpResponse<IImagen[]>) => {
      this.imagens = res.body;
    });
  }

  ngOnInit() {
    this.loadAll();
    this.registerChangeInImagens();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IImagen) {
    return item.id;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  registerChangeInImagens() {
    this.eventSubscriber = this.eventManager.subscribe('imagenListModification', () => this.loadAll());
  }

  delete(imagen: IImagen) {
    const modalRef = this.modalService.open(ImagenDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.imagen = imagen;
  }
}
