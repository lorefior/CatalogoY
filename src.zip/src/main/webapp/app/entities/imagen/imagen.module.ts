import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Catalog0SharedModule } from 'app/shared/shared.module';
import { ImagenComponent } from './imagen.component';
import { ImagenDetailComponent } from './imagen-detail.component';
import { ImagenUpdateComponent } from './imagen-update.component';
import { ImagenDeleteDialogComponent } from './imagen-delete-dialog.component';
import { imagenRoute } from './imagen.route';

@NgModule({
  imports: [Catalog0SharedModule, RouterModule.forChild(imagenRoute)],
  declarations: [ImagenComponent, ImagenDetailComponent, ImagenUpdateComponent, ImagenDeleteDialogComponent],
  entryComponents: [ImagenDeleteDialogComponent]
})
export class Catalog0ImagenModule {}
