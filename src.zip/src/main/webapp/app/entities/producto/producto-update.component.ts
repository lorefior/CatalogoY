import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';
import { IProducto, Producto } from 'app/shared/model/producto.model';
import { ProductoService } from './producto.service';
import { ITipoMoneda } from 'app/shared/model/tipo-moneda.model';
import { TipoMonedaService } from 'app/entities/tipo-moneda/tipo-moneda.service';
import { ISubcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from 'app/entities/subcategoria/subcategoria.service';

@Component({
  selector: 'jhi-producto-update',
  templateUrl: './producto-update.component.html'
})
export class ProductoUpdateComponent implements OnInit {
  isSaving: boolean;

  tipomonedas: ITipoMoneda[];

  subcategorias: ISubcategoria[];

  editForm = this.fb.group({
    id: [],
    titulo: [],
    descripcion: [],
    valor: [],
    moneda: [],
    subcategoria: []
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected productoService: ProductoService,
    protected tipoMonedaService: TipoMonedaService,
    protected subcategoriaService: SubcategoriaService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ producto }) => {
      this.updateForm(producto);
    });
    this.tipoMonedaService
      .query()
      .subscribe(
        (res: HttpResponse<ITipoMoneda[]>) => (this.tipomonedas = res.body),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
    this.subcategoriaService
      .query()
      .subscribe(
        (res: HttpResponse<ISubcategoria[]>) => (this.subcategorias = res.body),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  updateForm(producto: IProducto) {
    this.editForm.patchValue({
      id: producto.id,
      titulo: producto.titulo,
      descripcion: producto.descripcion,
      valor: producto.valor,
      moneda: producto.moneda,
      subcategoria: producto.subcategoria
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const producto = this.createFromForm();
    if (producto.id !== undefined) {
      this.subscribeToSaveResponse(this.productoService.update(producto));
    } else {
      this.subscribeToSaveResponse(this.productoService.create(producto));
    }
  }

  private createFromForm(): IProducto {
    return {
      ...new Producto(),
      id: this.editForm.get(['id']).value,
      titulo: this.editForm.get(['titulo']).value,
      descripcion: this.editForm.get(['descripcion']).value,
      valor: this.editForm.get(['valor']).value,
      moneda: this.editForm.get(['moneda']).value,
      subcategoria: this.editForm.get(['subcategoria']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProducto>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackTipoMonedaById(index: number, item: ITipoMoneda) {
    return item.id;
  }

  trackSubcategoriaById(index: number, item: ISubcategoria) {
    return item.id;
  }
}
