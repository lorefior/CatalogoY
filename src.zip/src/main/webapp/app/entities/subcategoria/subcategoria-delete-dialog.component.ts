import { Component } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ISubcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from './subcategoria.service';

@Component({
  templateUrl: './subcategoria-delete-dialog.component.html'
})
export class SubcategoriaDeleteDialogComponent {
  subcategoria: ISubcategoria;

  constructor(
    protected subcategoriaService: SubcategoriaService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  clear() {
    this.activeModal.dismiss('cancel');
  }

  confirmDelete(id: number) {
    this.subcategoriaService.delete(id).subscribe(() => {
      this.eventManager.broadcast({
        name: 'subcategoriaListModification',
        content: 'Deleted an subcategoria'
      });
      this.activeModal.dismiss(true);
    });
  }
}
