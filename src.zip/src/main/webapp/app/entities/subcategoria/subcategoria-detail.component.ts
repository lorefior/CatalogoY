import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ISubcategoria } from 'app/shared/model/subcategoria.model';

@Component({
  selector: 'jhi-subcategoria-detail',
  templateUrl: './subcategoria-detail.component.html'
})
export class SubcategoriaDetailComponent implements OnInit {
  subcategoria: ISubcategoria;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ subcategoria }) => {
      this.subcategoria = subcategoria;
    });
  }

  previousState() {
    window.history.back();
  }
}
