import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';
import { ISubcategoria, Subcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from './subcategoria.service';
import { ICategoria } from 'app/shared/model/categoria.model';
import { CategoriaService } from 'app/entities/categoria/categoria.service';

@Component({
  selector: 'jhi-subcategoria-update',
  templateUrl: './subcategoria-update.component.html'
})
export class SubcategoriaUpdateComponent implements OnInit {
  isSaving: boolean;

  categorias: ICategoria[];

  editForm = this.fb.group({
    id: [],
    descripcion: [],
    categoria: []
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected subcategoriaService: SubcategoriaService,
    protected categoriaService: CategoriaService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ subcategoria }) => {
      this.updateForm(subcategoria);
    });
    this.categoriaService
      .query()
      .subscribe((res: HttpResponse<ICategoria[]>) => (this.categorias = res.body), (res: HttpErrorResponse) => this.onError(res.message));
  }

  updateForm(subcategoria: ISubcategoria) {
    this.editForm.patchValue({
      id: subcategoria.id,
      descripcion: subcategoria.descripcion,
      categoria: subcategoria.categoria
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const subcategoria = this.createFromForm();
    if (subcategoria.id !== undefined) {
      this.subscribeToSaveResponse(this.subcategoriaService.update(subcategoria));
    } else {
      this.subscribeToSaveResponse(this.subcategoriaService.create(subcategoria));
    }
  }

  private createFromForm(): ISubcategoria {
    return {
      ...new Subcategoria(),
      id: this.editForm.get(['id']).value,
      descripcion: this.editForm.get(['descripcion']).value,
      categoria: this.editForm.get(['categoria']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ISubcategoria>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackCategoriaById(index: number, item: ICategoria) {
    return item.id;
  }
}
