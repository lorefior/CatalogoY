import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ISubcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from './subcategoria.service';
import { SubcategoriaDeleteDialogComponent } from './subcategoria-delete-dialog.component';

@Component({
  selector: 'jhi-subcategoria',
  templateUrl: './subcategoria.component.html'
})
export class SubcategoriaComponent implements OnInit, OnDestroy {
  subcategorias: ISubcategoria[];
  eventSubscriber: Subscription;

  constructor(
    protected subcategoriaService: SubcategoriaService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal
  ) {}

  loadAll() {
    this.subcategoriaService.query().subscribe((res: HttpResponse<ISubcategoria[]>) => {
      this.subcategorias = res.body;
    });
  }

  ngOnInit() {
    this.loadAll();
    this.registerChangeInSubcategorias();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ISubcategoria) {
    return item.id;
  }

  registerChangeInSubcategorias() {
    this.eventSubscriber = this.eventManager.subscribe('subcategoriaListModification', () => this.loadAll());
  }

  delete(subcategoria: ISubcategoria) {
    const modalRef = this.modalService.open(SubcategoriaDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.subcategoria = subcategoria;
  }
}
