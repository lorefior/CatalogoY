import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Catalog0SharedModule } from 'app/shared/shared.module';
import { SubcategoriaComponent } from './subcategoria.component';
import { SubcategoriaDetailComponent } from './subcategoria-detail.component';
import { SubcategoriaUpdateComponent } from './subcategoria-update.component';
import { SubcategoriaDeleteDialogComponent } from './subcategoria-delete-dialog.component';
import { subcategoriaRoute } from './subcategoria.route';

@NgModule({
  imports: [Catalog0SharedModule, RouterModule.forChild(subcategoriaRoute)],
  declarations: [SubcategoriaComponent, SubcategoriaDetailComponent, SubcategoriaUpdateComponent, SubcategoriaDeleteDialogComponent],
  entryComponents: [SubcategoriaDeleteDialogComponent]
})
export class Catalog0SubcategoriaModule {}
