import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Subcategoria } from 'app/shared/model/subcategoria.model';
import { SubcategoriaService } from './subcategoria.service';
import { SubcategoriaComponent } from './subcategoria.component';
import { SubcategoriaDetailComponent } from './subcategoria-detail.component';
import { SubcategoriaUpdateComponent } from './subcategoria-update.component';
import { ISubcategoria } from 'app/shared/model/subcategoria.model';

@Injectable({ providedIn: 'root' })
export class SubcategoriaResolve implements Resolve<ISubcategoria> {
  constructor(private service: SubcategoriaService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ISubcategoria> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(map((subcategoria: HttpResponse<Subcategoria>) => subcategoria.body));
    }
    return of(new Subcategoria());
  }
}

export const subcategoriaRoute: Routes = [
  {
    path: '',
    component: SubcategoriaComponent,
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.subcategoria.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: SubcategoriaDetailComponent,
    resolve: {
      subcategoria: SubcategoriaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.subcategoria.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: SubcategoriaUpdateComponent,
    resolve: {
      subcategoria: SubcategoriaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.subcategoria.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: SubcategoriaUpdateComponent,
    resolve: {
      subcategoria: SubcategoriaResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.subcategoria.home.title'
    },
    canActivate: [UserRouteAccessService]
  }
];
