import { Component } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ITipoDato } from 'app/shared/model/tipo-dato.model';
import { TipoDatoService } from './tipo-dato.service';

@Component({
  templateUrl: './tipo-dato-delete-dialog.component.html'
})
export class TipoDatoDeleteDialogComponent {
  tipoDato: ITipoDato;

  constructor(protected tipoDatoService: TipoDatoService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  clear() {
    this.activeModal.dismiss('cancel');
  }

  confirmDelete(id: number) {
    this.tipoDatoService.delete(id).subscribe(() => {
      this.eventManager.broadcast({
        name: 'tipoDatoListModification',
        content: 'Deleted an tipoDato'
      });
      this.activeModal.dismiss(true);
    });
  }
}
