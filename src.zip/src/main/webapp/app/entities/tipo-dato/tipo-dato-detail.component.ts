import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ITipoDato } from 'app/shared/model/tipo-dato.model';

@Component({
  selector: 'jhi-tipo-dato-detail',
  templateUrl: './tipo-dato-detail.component.html'
})
export class TipoDatoDetailComponent implements OnInit {
  tipoDato: ITipoDato;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ tipoDato }) => {
      this.tipoDato = tipoDato;
    });
  }

  previousState() {
    window.history.back();
  }
}
