import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { ITipoDato, TipoDato } from 'app/shared/model/tipo-dato.model';
import { TipoDatoService } from './tipo-dato.service';

@Component({
  selector: 'jhi-tipo-dato-update',
  templateUrl: './tipo-dato-update.component.html'
})
export class TipoDatoUpdateComponent implements OnInit {
  isSaving: boolean;

  editForm = this.fb.group({
    id: [],
    valor: []
  });

  constructor(protected tipoDatoService: TipoDatoService, protected activatedRoute: ActivatedRoute, private fb: FormBuilder) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ tipoDato }) => {
      this.updateForm(tipoDato);
    });
  }

  updateForm(tipoDato: ITipoDato) {
    this.editForm.patchValue({
      id: tipoDato.id,
      valor: tipoDato.valor
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const tipoDato = this.createFromForm();
    if (tipoDato.id !== undefined) {
      this.subscribeToSaveResponse(this.tipoDatoService.update(tipoDato));
    } else {
      this.subscribeToSaveResponse(this.tipoDatoService.create(tipoDato));
    }
  }

  private createFromForm(): ITipoDato {
    return {
      ...new TipoDato(),
      id: this.editForm.get(['id']).value,
      valor: this.editForm.get(['valor']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ITipoDato>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
}
