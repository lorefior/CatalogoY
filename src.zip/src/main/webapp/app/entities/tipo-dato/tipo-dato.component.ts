import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ITipoDato } from 'app/shared/model/tipo-dato.model';
import { TipoDatoService } from './tipo-dato.service';
import { TipoDatoDeleteDialogComponent } from './tipo-dato-delete-dialog.component';

@Component({
  selector: 'jhi-tipo-dato',
  templateUrl: './tipo-dato.component.html'
})
export class TipoDatoComponent implements OnInit, OnDestroy {
  tipoDatoes: ITipoDato[];
  eventSubscriber: Subscription;

  constructor(protected tipoDatoService: TipoDatoService, protected eventManager: JhiEventManager, protected modalService: NgbModal) {}

  loadAll() {
    this.tipoDatoService.query().subscribe((res: HttpResponse<ITipoDato[]>) => {
      this.tipoDatoes = res.body;
    });
  }

  ngOnInit() {
    this.loadAll();
    this.registerChangeInTipoDatoes();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ITipoDato) {
    return item.id;
  }

  registerChangeInTipoDatoes() {
    this.eventSubscriber = this.eventManager.subscribe('tipoDatoListModification', () => this.loadAll());
  }

  delete(tipoDato: ITipoDato) {
    const modalRef = this.modalService.open(TipoDatoDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.tipoDato = tipoDato;
  }
}
