import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Catalog0SharedModule } from 'app/shared/shared.module';
import { TipoDatoComponent } from './tipo-dato.component';
import { TipoDatoDetailComponent } from './tipo-dato-detail.component';
import { TipoDatoUpdateComponent } from './tipo-dato-update.component';
import { TipoDatoDeleteDialogComponent } from './tipo-dato-delete-dialog.component';
import { tipoDatoRoute } from './tipo-dato.route';

@NgModule({
  imports: [Catalog0SharedModule, RouterModule.forChild(tipoDatoRoute)],
  declarations: [TipoDatoComponent, TipoDatoDetailComponent, TipoDatoUpdateComponent, TipoDatoDeleteDialogComponent],
  entryComponents: [TipoDatoDeleteDialogComponent]
})
export class Catalog0TipoDatoModule {}
