import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { TipoDato } from 'app/shared/model/tipo-dato.model';
import { TipoDatoService } from './tipo-dato.service';
import { TipoDatoComponent } from './tipo-dato.component';
import { TipoDatoDetailComponent } from './tipo-dato-detail.component';
import { TipoDatoUpdateComponent } from './tipo-dato-update.component';
import { ITipoDato } from 'app/shared/model/tipo-dato.model';

@Injectable({ providedIn: 'root' })
export class TipoDatoResolve implements Resolve<ITipoDato> {
  constructor(private service: TipoDatoService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ITipoDato> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(map((tipoDato: HttpResponse<TipoDato>) => tipoDato.body));
    }
    return of(new TipoDato());
  }
}

export const tipoDatoRoute: Routes = [
  {
    path: '',
    component: TipoDatoComponent,
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.tipoDato.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: TipoDatoDetailComponent,
    resolve: {
      tipoDato: TipoDatoResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.tipoDato.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: TipoDatoUpdateComponent,
    resolve: {
      tipoDato: TipoDatoResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.tipoDato.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: TipoDatoUpdateComponent,
    resolve: {
      tipoDato: TipoDatoResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.tipoDato.home.title'
    },
    canActivate: [UserRouteAccessService]
  }
];
