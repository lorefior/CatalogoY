import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ITipoMoneda } from 'app/shared/model/tipo-moneda.model';

@Component({
  selector: 'jhi-tipo-moneda-detail',
  templateUrl: './tipo-moneda-detail.component.html'
})
export class TipoMonedaDetailComponent implements OnInit {
  tipoMoneda: ITipoMoneda;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ tipoMoneda }) => {
      this.tipoMoneda = tipoMoneda;
    });
  }

  previousState() {
    window.history.back();
  }
}
