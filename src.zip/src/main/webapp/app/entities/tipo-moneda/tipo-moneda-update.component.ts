import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { ITipoMoneda, TipoMoneda } from 'app/shared/model/tipo-moneda.model';
import { TipoMonedaService } from './tipo-moneda.service';

@Component({
  selector: 'jhi-tipo-moneda-update',
  templateUrl: './tipo-moneda-update.component.html'
})
export class TipoMonedaUpdateComponent implements OnInit {
  isSaving: boolean;

  editForm = this.fb.group({
    id: [],
    codigo: [],
    nombre: []
  });

  constructor(protected tipoMonedaService: TipoMonedaService, protected activatedRoute: ActivatedRoute, private fb: FormBuilder) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ tipoMoneda }) => {
      this.updateForm(tipoMoneda);
    });
  }

  updateForm(tipoMoneda: ITipoMoneda) {
    this.editForm.patchValue({
      id: tipoMoneda.id,
      codigo: tipoMoneda.codigo,
      nombre: tipoMoneda.nombre
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const tipoMoneda = this.createFromForm();
    if (tipoMoneda.id !== undefined) {
      this.subscribeToSaveResponse(this.tipoMonedaService.update(tipoMoneda));
    } else {
      this.subscribeToSaveResponse(this.tipoMonedaService.create(tipoMoneda));
    }
  }

  private createFromForm(): ITipoMoneda {
    return {
      ...new TipoMoneda(),
      id: this.editForm.get(['id']).value,
      codigo: this.editForm.get(['codigo']).value,
      nombre: this.editForm.get(['nombre']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ITipoMoneda>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
}
