import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ITipoMoneda } from 'app/shared/model/tipo-moneda.model';
import { TipoMonedaService } from './tipo-moneda.service';
import { TipoMonedaDeleteDialogComponent } from './tipo-moneda-delete-dialog.component';

@Component({
  selector: 'jhi-tipo-moneda',
  templateUrl: './tipo-moneda.component.html'
})
export class TipoMonedaComponent implements OnInit, OnDestroy {
  tipoMonedas: ITipoMoneda[];
  eventSubscriber: Subscription;

  constructor(protected tipoMonedaService: TipoMonedaService, protected eventManager: JhiEventManager, protected modalService: NgbModal) {}

  loadAll() {
    this.tipoMonedaService.query().subscribe((res: HttpResponse<ITipoMoneda[]>) => {
      this.tipoMonedas = res.body;
    });
  }

  ngOnInit() {
    this.loadAll();
    this.registerChangeInTipoMonedas();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ITipoMoneda) {
    return item.id;
  }

  registerChangeInTipoMonedas() {
    this.eventSubscriber = this.eventManager.subscribe('tipoMonedaListModification', () => this.loadAll());
  }

  delete(tipoMoneda: ITipoMoneda) {
    const modalRef = this.modalService.open(TipoMonedaDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.tipoMoneda = tipoMoneda;
  }
}
