import { Component } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IValor } from 'app/shared/model/valor.model';
import { ValorService } from './valor.service';

@Component({
  templateUrl: './valor-delete-dialog.component.html'
})
export class ValorDeleteDialogComponent {
  valor: IValor;

  constructor(protected valorService: ValorService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  clear() {
    this.activeModal.dismiss('cancel');
  }

  confirmDelete(id: number) {
    this.valorService.delete(id).subscribe(() => {
      this.eventManager.broadcast({
        name: 'valorListModification',
        content: 'Deleted an valor'
      });
      this.activeModal.dismiss(true);
    });
  }
}
