import { Component, OnInit } from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';
import { IValor, Valor } from 'app/shared/model/valor.model';
import { ValorService } from './valor.service';
import { ICaracteristica } from 'app/shared/model/caracteristica.model';
import { CaracteristicaService } from 'app/entities/caracteristica/caracteristica.service';
import { IProducto } from 'app/shared/model/producto.model';
import { ProductoService } from 'app/entities/producto/producto.service';

@Component({
  selector: 'jhi-valor-update',
  templateUrl: './valor-update.component.html'
})
export class ValorUpdateComponent implements OnInit {
  isSaving: boolean;

  caracteristicas: ICaracteristica[];

  productos: IProducto[];

  editForm = this.fb.group({
    id: [],
    valor: [],
    caracteristica: [],
    producto: []
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected valorService: ValorService,
    protected caracteristicaService: CaracteristicaService,
    protected productoService: ProductoService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ valor }) => {
      this.updateForm(valor);
    });
    this.caracteristicaService
      .query()
      .subscribe(
        (res: HttpResponse<ICaracteristica[]>) => (this.caracteristicas = res.body),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
    this.productoService
      .query()
      .subscribe((res: HttpResponse<IProducto[]>) => (this.productos = res.body), (res: HttpErrorResponse) => this.onError(res.message));
  }

  updateForm(valor: IValor) {
    this.editForm.patchValue({
      id: valor.id,
      valor: valor.valor,
      caracteristica: valor.caracteristica,
      producto: valor.producto
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const valor = this.createFromForm();
    if (valor.id !== undefined) {
      this.subscribeToSaveResponse(this.valorService.update(valor));
    } else {
      this.subscribeToSaveResponse(this.valorService.create(valor));
    }
  }

  private createFromForm(): IValor {
    return {
      ...new Valor(),
      id: this.editForm.get(['id']).value,
      valor: this.editForm.get(['valor']).value,
      caracteristica: this.editForm.get(['caracteristica']).value,
      producto: this.editForm.get(['producto']).value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IValor>>) {
    result.subscribe(() => this.onSaveSuccess(), () => this.onSaveError());
  }

  protected onSaveSuccess() {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError() {
    this.isSaving = false;
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackCaracteristicaById(index: number, item: ICaracteristica) {
    return item.id;
  }

  trackProductoById(index: number, item: IProducto) {
    return item.id;
  }
}
