import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Catalog0SharedModule } from 'app/shared/shared.module';
import { ValorComponent } from './valor.component';
import { ValorDetailComponent } from './valor-detail.component';
import { ValorUpdateComponent } from './valor-update.component';
import { ValorDeleteDialogComponent } from './valor-delete-dialog.component';
import { valorRoute } from './valor.route';

@NgModule({
  imports: [Catalog0SharedModule, RouterModule.forChild(valorRoute)],
  declarations: [ValorComponent, ValorDetailComponent, ValorUpdateComponent, ValorDeleteDialogComponent],
  entryComponents: [ValorDeleteDialogComponent]
})
export class Catalog0ValorModule {}
