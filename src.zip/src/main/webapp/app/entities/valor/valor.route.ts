import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Valor } from 'app/shared/model/valor.model';
import { ValorService } from './valor.service';
import { ValorComponent } from './valor.component';
import { ValorDetailComponent } from './valor-detail.component';
import { ValorUpdateComponent } from './valor-update.component';
import { IValor } from 'app/shared/model/valor.model';

@Injectable({ providedIn: 'root' })
export class ValorResolve implements Resolve<IValor> {
  constructor(private service: ValorService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IValor> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(map((valor: HttpResponse<Valor>) => valor.body));
    }
    return of(new Valor());
  }
}

export const valorRoute: Routes = [
  {
    path: '',
    component: ValorComponent,
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.valor.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/view',
    component: ValorDetailComponent,
    resolve: {
      valor: ValorResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.valor.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: 'new',
    component: ValorUpdateComponent,
    resolve: {
      valor: ValorResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.valor.home.title'
    },
    canActivate: [UserRouteAccessService]
  },
  {
    path: ':id/edit',
    component: ValorUpdateComponent,
    resolve: {
      valor: ValorResolve
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'catalog0App.valor.home.title'
    },
    canActivate: [UserRouteAccessService]
  }
];
