import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared/util/request-util';
import { IValor } from 'app/shared/model/valor.model';

type EntityResponseType = HttpResponse<IValor>;
type EntityArrayResponseType = HttpResponse<IValor[]>;

@Injectable({ providedIn: 'root' })
export class ValorService {
  public resourceUrl = SERVER_API_URL + 'api/valors';

  constructor(protected http: HttpClient) {}

  create(valor: IValor): Observable<EntityResponseType> {
    return this.http.post<IValor>(this.resourceUrl, valor, { observe: 'response' });
  }

  update(valor: IValor): Observable<EntityResponseType> {
    return this.http.put<IValor>(this.resourceUrl, valor, { observe: 'response' });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IValor>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IValor[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }
}
