import { IValor } from 'app/shared/model/valor.model';
import { ITipoDato } from 'app/shared/model/tipo-dato.model';
import { ISubcategoria } from 'app/shared/model/subcategoria.model';

export interface ICaracteristica {
  id?: number;
  nombre?: string;
  valors?: IValor[];
  dato?: ITipoDato;
  subcategoria?: ISubcategoria;
}

export class Caracteristica implements ICaracteristica {
  constructor(
    public id?: number,
    public nombre?: string,
    public valors?: IValor[],
    public dato?: ITipoDato,
    public subcategoria?: ISubcategoria
  ) {}
}
