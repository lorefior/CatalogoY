export interface ICategoria {
  id?: number;
  descripcion?: string;
}

export class Categoria implements ICategoria {
  constructor(public id?: number, public descripcion?: string) {}
}
