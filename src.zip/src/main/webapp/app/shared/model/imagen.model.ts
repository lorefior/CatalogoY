import { IProducto } from 'app/shared/model/producto.model';

export interface IImagen {
  id?: number;
  imagenProductoContentType?: string;
  imagenProducto?: any;
  producto?: IProducto;
}

export class Imagen implements IImagen {
  constructor(public id?: number, public imagenProductoContentType?: string, public imagenProducto?: any, public producto?: IProducto) {}
}
