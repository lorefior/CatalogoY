import { IImagen } from 'app/shared/model/imagen.model';
import { IValor } from 'app/shared/model/valor.model';
import { ITipoMoneda } from 'app/shared/model/tipo-moneda.model';
import { ISubcategoria } from 'app/shared/model/subcategoria.model';

export interface IProducto {
  id?: number;
  titulo?: string;
  descripcion?: string;
  valor?: number;
  imagens?: IImagen[];
  valors?: IValor[];
  moneda?: ITipoMoneda;
  subcategoria?: ISubcategoria;
}

export class Producto implements IProducto {
  constructor(
    public id?: number,
    public titulo?: string,
    public descripcion?: string,
    public valor?: number,
    public imagens?: IImagen[],
    public valors?: IValor[],
    public moneda?: ITipoMoneda,
    public subcategoria?: ISubcategoria
  ) {}
}
