import { ICaracteristica } from 'app/shared/model/caracteristica.model';
import { ICategoria } from 'app/shared/model/categoria.model';

export interface ISubcategoria {
  id?: number;
  descripcion?: string;
  caracteristicas?: ICaracteristica[];
  categoria?: ICategoria;
}

export class Subcategoria implements ISubcategoria {
  constructor(public id?: number, public descripcion?: string, public caracteristicas?: ICaracteristica[], public categoria?: ICategoria) {}
}
