export interface ITipoDato {
  id?: number;
  valor?: string;
}

export class TipoDato implements ITipoDato {
  constructor(public id?: number, public valor?: string) {}
}
