export interface ITipoMoneda {
  id?: number;
  codigo?: string;
  nombre?: string;
}

export class TipoMoneda implements ITipoMoneda {
  constructor(public id?: number, public codigo?: string, public nombre?: string) {}
}
