import { ICaracteristica } from 'app/shared/model/caracteristica.model';
import { IProducto } from 'app/shared/model/producto.model';

export interface IValor {
  id?: number;
  valor?: string;
  caracteristica?: ICaracteristica;
  producto?: IProducto;
}

export class Valor implements IValor {
  constructor(public id?: number, public valor?: string, public caracteristica?: ICaracteristica, public producto?: IProducto) {}
}
