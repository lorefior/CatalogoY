package com.cdainfo.catalogosubasta.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.cdainfo.catalogosubasta.web.rest.TestUtil;

public class TipoDatoTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TipoDato.class);
        TipoDato tipoDato1 = new TipoDato();
        tipoDato1.setId(1L);
        TipoDato tipoDato2 = new TipoDato();
        tipoDato2.setId(tipoDato1.getId());
        assertThat(tipoDato1).isEqualTo(tipoDato2);
        tipoDato2.setId(2L);
        assertThat(tipoDato1).isNotEqualTo(tipoDato2);
        tipoDato1.setId(null);
        assertThat(tipoDato1).isNotEqualTo(tipoDato2);
    }
}
