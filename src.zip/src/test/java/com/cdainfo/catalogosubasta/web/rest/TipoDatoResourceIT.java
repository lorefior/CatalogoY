package com.cdainfo.catalogosubasta.web.rest;

import com.cdainfo.catalogosubasta.Catalog0App;
import com.cdainfo.catalogosubasta.domain.TipoDato;
import com.cdainfo.catalogosubasta.repository.TipoDatoRepository;
import com.cdainfo.catalogosubasta.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.cdainfo.catalogosubasta.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link TipoDatoResource} REST controller.
 */
@SpringBootTest(classes = Catalog0App.class)
public class TipoDatoResourceIT {

    private static final String DEFAULT_VALOR = "AAAAAAAAAA";
    private static final String UPDATED_VALOR = "BBBBBBBBBB";

    @Autowired
    private TipoDatoRepository tipoDatoRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restTipoDatoMockMvc;

    private TipoDato tipoDato;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final TipoDatoResource tipoDatoResource = new TipoDatoResource(tipoDatoRepository);
        this.restTipoDatoMockMvc = MockMvcBuilders.standaloneSetup(tipoDatoResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TipoDato createEntity(EntityManager em) {
        TipoDato tipoDato = new TipoDato()
            .valor(DEFAULT_VALOR);
        return tipoDato;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TipoDato createUpdatedEntity(EntityManager em) {
        TipoDato tipoDato = new TipoDato()
            .valor(UPDATED_VALOR);
        return tipoDato;
    }

    @BeforeEach
    public void initTest() {
        tipoDato = createEntity(em);
    }

    @Test
    @Transactional
    public void createTipoDato() throws Exception {
        int databaseSizeBeforeCreate = tipoDatoRepository.findAll().size();

        // Create the TipoDato
        restTipoDatoMockMvc.perform(post("/api/tipo-datoes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(tipoDato)))
            .andExpect(status().isCreated());

        // Validate the TipoDato in the database
        List<TipoDato> tipoDatoList = tipoDatoRepository.findAll();
        assertThat(tipoDatoList).hasSize(databaseSizeBeforeCreate + 1);
        TipoDato testTipoDato = tipoDatoList.get(tipoDatoList.size() - 1);
        assertThat(testTipoDato.getValor()).isEqualTo(DEFAULT_VALOR);
    }

    @Test
    @Transactional
    public void createTipoDatoWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = tipoDatoRepository.findAll().size();

        // Create the TipoDato with an existing ID
        tipoDato.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restTipoDatoMockMvc.perform(post("/api/tipo-datoes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(tipoDato)))
            .andExpect(status().isBadRequest());

        // Validate the TipoDato in the database
        List<TipoDato> tipoDatoList = tipoDatoRepository.findAll();
        assertThat(tipoDatoList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllTipoDatoes() throws Exception {
        // Initialize the database
        tipoDatoRepository.saveAndFlush(tipoDato);

        // Get all the tipoDatoList
        restTipoDatoMockMvc.perform(get("/api/tipo-datoes?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(tipoDato.getId().intValue())))
            .andExpect(jsonPath("$.[*].valor").value(hasItem(DEFAULT_VALOR)));
    }
    
    @Test
    @Transactional
    public void getTipoDato() throws Exception {
        // Initialize the database
        tipoDatoRepository.saveAndFlush(tipoDato);

        // Get the tipoDato
        restTipoDatoMockMvc.perform(get("/api/tipo-datoes/{id}", tipoDato.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(tipoDato.getId().intValue()))
            .andExpect(jsonPath("$.valor").value(DEFAULT_VALOR));
    }

    @Test
    @Transactional
    public void getNonExistingTipoDato() throws Exception {
        // Get the tipoDato
        restTipoDatoMockMvc.perform(get("/api/tipo-datoes/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateTipoDato() throws Exception {
        // Initialize the database
        tipoDatoRepository.saveAndFlush(tipoDato);

        int databaseSizeBeforeUpdate = tipoDatoRepository.findAll().size();

        // Update the tipoDato
        TipoDato updatedTipoDato = tipoDatoRepository.findById(tipoDato.getId()).get();
        // Disconnect from session so that the updates on updatedTipoDato are not directly saved in db
        em.detach(updatedTipoDato);
        updatedTipoDato
            .valor(UPDATED_VALOR);

        restTipoDatoMockMvc.perform(put("/api/tipo-datoes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedTipoDato)))
            .andExpect(status().isOk());

        // Validate the TipoDato in the database
        List<TipoDato> tipoDatoList = tipoDatoRepository.findAll();
        assertThat(tipoDatoList).hasSize(databaseSizeBeforeUpdate);
        TipoDato testTipoDato = tipoDatoList.get(tipoDatoList.size() - 1);
        assertThat(testTipoDato.getValor()).isEqualTo(UPDATED_VALOR);
    }

    @Test
    @Transactional
    public void updateNonExistingTipoDato() throws Exception {
        int databaseSizeBeforeUpdate = tipoDatoRepository.findAll().size();

        // Create the TipoDato

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTipoDatoMockMvc.perform(put("/api/tipo-datoes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(tipoDato)))
            .andExpect(status().isBadRequest());

        // Validate the TipoDato in the database
        List<TipoDato> tipoDatoList = tipoDatoRepository.findAll();
        assertThat(tipoDatoList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteTipoDato() throws Exception {
        // Initialize the database
        tipoDatoRepository.saveAndFlush(tipoDato);

        int databaseSizeBeforeDelete = tipoDatoRepository.findAll().size();

        // Delete the tipoDato
        restTipoDatoMockMvc.perform(delete("/api/tipo-datoes/{id}", tipoDato.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TipoDato> tipoDatoList = tipoDatoRepository.findAll();
        assertThat(tipoDatoList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
